#### Changelog:

`v1.0.4` -> `v1.0.5`
```diff
+ Fix time formatting for songs 1 hour or longer
+ Twitch panel now only opens on song select screen
```

`v1.0.2` -> `v1.0.4`

```diff
+ Sub-only requests mode
+ Updated to use the new ReloadManager code
```

`v1.0.1` -> `v1.0.2`

```diff
+ Theme Compatibility fixes
+ Various minor optimization
```

`v1.0.0` -> `v1.0.1`

```diff
+ Compatiblity update for Multiplayer
```

`v0.1.0` -> `v1.0.0`

```diff
+ Request songs using !ttr
+ Show profile with !profile
+ Link current song with !song
```

